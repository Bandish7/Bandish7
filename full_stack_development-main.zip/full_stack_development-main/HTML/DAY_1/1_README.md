### Learn
# Introudction to HTML
 HTML provides structure to the content appearing on a website, such as images, text, or videos. Right-click on any page on the internet, choose “Inspect,” and you’ll see HTML in a panel of your screen.

HTML stands for HyperText Markup Language:

* A markup language is a computer language that defines the structure and presentation of raw text.
* In HTML, the computer can interpret raw text that is wrapped in HTML elements.
* HyperText is text displayed on a computer or device that provides access to other text through links, also known as hyperlinks.

### Instructions
In the code editor to the right, type your name in between `<h1>` and `</h1>`.

### Questions
* Which programming language should I choose?
* What are HTML Elements
* Why would raw text need a structure